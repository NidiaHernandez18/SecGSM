﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmWS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.optfxLogin = New System.Windows.Forms.RadioButton()
        Me.optUpdateCLUS = New System.Windows.Forms.RadioButton()
        Me.optUpdateCliente = New System.Windows.Forms.RadioButton()
        Me.optUpdateCatTimbres = New System.Windows.Forms.RadioButton()
        Me.optUpdateMsgs = New System.Windows.Forms.RadioButton()
        Me.optGetInfo = New System.Windows.Forms.RadioButton()
        Me.p101 = New System.Windows.Forms.TextBox()
        Me.txtResultado = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabfxLogin = New System.Windows.Forms.TabPage()
        Me.cmd1 = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.p106 = New System.Windows.Forms.TextBox()
        Me.p105 = New System.Windows.Forms.TextBox()
        Me.p104 = New System.Windows.Forms.TextBox()
        Me.p103 = New System.Windows.Forms.TextBox()
        Me.p102 = New System.Windows.Forms.TextBox()
        Me.tabSign_Cancel = New System.Windows.Forms.TabPage()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.p222 = New System.Windows.Forms.TextBox()
        Me.p221 = New System.Windows.Forms.TextBox()
        Me.p220 = New System.Windows.Forms.TextBox()
        Me.p219 = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.p218 = New System.Windows.Forms.TextBox()
        Me.p217 = New System.Windows.Forms.TextBox()
        Me.p216 = New System.Windows.Forms.TextBox()
        Me.p215 = New System.Windows.Forms.TextBox()
        Me.p214 = New System.Windows.Forms.TextBox()
        Me.p213 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.p212 = New System.Windows.Forms.TextBox()
        Me.p211 = New System.Windows.Forms.TextBox()
        Me.p210 = New System.Windows.Forms.TextBox()
        Me.p209 = New System.Windows.Forms.TextBox()
        Me.p208 = New System.Windows.Forms.TextBox()
        Me.p207 = New System.Windows.Forms.TextBox()
        Me.cmd2 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.p206 = New System.Windows.Forms.TextBox()
        Me.p205 = New System.Windows.Forms.TextBox()
        Me.p204 = New System.Windows.Forms.TextBox()
        Me.p203 = New System.Windows.Forms.TextBox()
        Me.p202 = New System.Windows.Forms.TextBox()
        Me.p201 = New System.Windows.Forms.TextBox()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.tabUpdateCliente = New System.Windows.Forms.TabPage()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.p307 = New System.Windows.Forms.TextBox()
        Me.cmd3 = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.p306 = New System.Windows.Forms.TextBox()
        Me.p305 = New System.Windows.Forms.TextBox()
        Me.p304 = New System.Windows.Forms.TextBox()
        Me.p303 = New System.Windows.Forms.TextBox()
        Me.p302 = New System.Windows.Forms.TextBox()
        Me.p301 = New System.Windows.Forms.TextBox()
        Me.tabUpdateCLUS = New System.Windows.Forms.TabPage()
        Me.cmd4 = New System.Windows.Forms.Button()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.p415 = New System.Windows.Forms.TextBox()
        Me.p414 = New System.Windows.Forms.TextBox()
        Me.p413 = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.p412 = New System.Windows.Forms.TextBox()
        Me.p411 = New System.Windows.Forms.TextBox()
        Me.p410 = New System.Windows.Forms.TextBox()
        Me.p409 = New System.Windows.Forms.TextBox()
        Me.p408 = New System.Windows.Forms.TextBox()
        Me.p407 = New System.Windows.Forms.TextBox()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.p406 = New System.Windows.Forms.TextBox()
        Me.p405 = New System.Windows.Forms.TextBox()
        Me.p404 = New System.Windows.Forms.TextBox()
        Me.p403 = New System.Windows.Forms.TextBox()
        Me.p402 = New System.Windows.Forms.TextBox()
        Me.p401 = New System.Windows.Forms.TextBox()
        Me.tabUpdateMsgs = New System.Windows.Forms.TabPage()
        Me.cmd5 = New System.Windows.Forms.Button()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.p506 = New System.Windows.Forms.TextBox()
        Me.p505 = New System.Windows.Forms.TextBox()
        Me.p504 = New System.Windows.Forms.TextBox()
        Me.p503 = New System.Windows.Forms.TextBox()
        Me.p502 = New System.Windows.Forms.TextBox()
        Me.p501 = New System.Windows.Forms.TextBox()
        Me.tabUpdateCatTimbres = New System.Windows.Forms.TabPage()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.p608 = New System.Windows.Forms.TextBox()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.p607 = New System.Windows.Forms.TextBox()
        Me.cmd6 = New System.Windows.Forms.Button()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.p606 = New System.Windows.Forms.TextBox()
        Me.p605 = New System.Windows.Forms.TextBox()
        Me.p604 = New System.Windows.Forms.TextBox()
        Me.p603 = New System.Windows.Forms.TextBox()
        Me.p602 = New System.Windows.Forms.TextBox()
        Me.p601 = New System.Windows.Forms.TextBox()
        Me.tabGetInfo = New System.Windows.Forms.TabPage()
        Me.p701 = New System.Windows.Forms.ComboBox()
        Me.GridGetInfo = New System.Windows.Forms.DataGridView()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.p702 = New System.Windows.Forms.TextBox()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.cmd7 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.tabfxLogin.SuspendLayout()
        Me.tabSign_Cancel.SuspendLayout()
        Me.tabUpdateCliente.SuspendLayout()
        Me.tabUpdateCLUS.SuspendLayout()
        Me.tabUpdateMsgs.SuspendLayout()
        Me.tabUpdateCatTimbres.SuspendLayout()
        Me.tabGetInfo.SuspendLayout()
        CType(Me.GridGetInfo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'optfxLogin
        '
        Me.optfxLogin.AutoSize = True
        Me.optfxLogin.Checked = True
        Me.optfxLogin.Location = New System.Drawing.Point(19, 6)
        Me.optfxLogin.Name = "optfxLogin"
        Me.optfxLogin.Size = New System.Drawing.Size(374, 17)
        Me.optfxLogin.TabIndex = 2
        Me.optfxLogin.TabStop = True
        Me.optfxLogin.Text = "fxLogin ($RFC, $NoCertificado, $Sistema, $Empresa, $Sucursal, $Usuario)"
        Me.optfxLogin.UseVisualStyleBackColor = True
        '
        'optUpdateCLUS
        '
        Me.optUpdateCLUS.Location = New System.Drawing.Point(17, 18)
        Me.optUpdateCLUS.Name = "optUpdateCLUS"
        Me.optUpdateCLUS.Size = New System.Drawing.Size(532, 43)
        Me.optUpdateCLUS.TabIndex = 5
        Me.optUpdateCLUS.Text = "UpdateCLUS ($NED,$IDCLU,$NoSerie,$IDCliente,$RFC,$Sistema,$Modulos, $ValidoDesde," & _
            " $ValidoHasta, $CanAccess,$CanSign,$CanCancel,$KindOfAccess,$Estatus,$Observacio" & _
            "nes)"
        Me.optUpdateCLUS.UseVisualStyleBackColor = True
        '
        'optUpdateCliente
        '
        Me.optUpdateCliente.AutoSize = True
        Me.optUpdateCliente.Checked = True
        Me.optUpdateCliente.Location = New System.Drawing.Point(15, 19)
        Me.optUpdateCliente.Name = "optUpdateCliente"
        Me.optUpdateCliente.Size = New System.Drawing.Size(447, 17)
        Me.optUpdateCliente.TabIndex = 4
        Me.optUpdateCliente.TabStop = True
        Me.optUpdateCliente.Text = "UpdateCliente ($NED,$IDCliente,$Nombre,$RFC,$ISOK, $MustContact, $Observaciones)"
        Me.optUpdateCliente.UseVisualStyleBackColor = True
        '
        'optUpdateCatTimbres
        '
        Me.optUpdateCatTimbres.Location = New System.Drawing.Point(6, 6)
        Me.optUpdateCatTimbres.Name = "optUpdateCatTimbres"
        Me.optUpdateCatTimbres.Size = New System.Drawing.Size(539, 34)
        Me.optUpdateCatTimbres.TabIndex = 7
        Me.optUpdateCatTimbres.Text = "UpdateCatTimbres ($NED,$IDCatTimbre,$IDCliente,$RFC,$ContratadoEl,$TotalTimbres,$" & _
            "Estatus,$Observaciones)"
        Me.optUpdateCatTimbres.UseVisualStyleBackColor = True
        '
        'optUpdateMsgs
        '
        Me.optUpdateMsgs.AutoSize = True
        Me.optUpdateMsgs.Location = New System.Drawing.Point(6, 16)
        Me.optUpdateMsgs.Name = "optUpdateMsgs"
        Me.optUpdateMsgs.Size = New System.Drawing.Size(407, 17)
        Me.optUpdateMsgs.TabIndex = 6
        Me.optUpdateMsgs.Text = "UpdateMsgs ($NED,$IDMsgs,$IDCliente,$Mensaje,$ValidoDesde, $ValidoHasta)"
        Me.optUpdateMsgs.UseVisualStyleBackColor = True
        '
        'optGetInfo
        '
        Me.optGetInfo.AutoSize = True
        Me.optGetInfo.Location = New System.Drawing.Point(15, 15)
        Me.optGetInfo.Name = "optGetInfo"
        Me.optGetInfo.Size = New System.Drawing.Size(134, 17)
        Me.optGetInfo.TabIndex = 8
        Me.optGetInfo.Text = "GetInfo ($tabla,$Filtros)"
        Me.optGetInfo.UseVisualStyleBackColor = True
        '
        'p101
        '
        Me.p101.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p101.Location = New System.Drawing.Point(116, 29)
        Me.p101.Name = "p101"
        Me.p101.Size = New System.Drawing.Size(264, 20)
        Me.p101.TabIndex = 9
        Me.p101.Text = "GSM010301EG4"
        '
        'txtResultado
        '
        Me.txtResultado.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtResultado.Font = New System.Drawing.Font("Courier New", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtResultado.Location = New System.Drawing.Point(577, 34)
        Me.txtResultado.Multiline = True
        Me.txtResultado.Name = "txtResultado"
        Me.txtResultado.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtResultado.Size = New System.Drawing.Size(441, 485)
        Me.txtResultado.TabIndex = 18
        '
        'Label1
        '
        Me.Label1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(577, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(94, 13)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "------ RESULTADO"
        '
        'TabControl1
        '
        Me.TabControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TabControl1.Controls.Add(Me.tabfxLogin)
        Me.TabControl1.Controls.Add(Me.tabSign_Cancel)
        Me.TabControl1.Controls.Add(Me.tabUpdateCliente)
        Me.TabControl1.Controls.Add(Me.tabUpdateCLUS)
        Me.TabControl1.Controls.Add(Me.tabUpdateMsgs)
        Me.TabControl1.Controls.Add(Me.tabUpdateCatTimbres)
        Me.TabControl1.Controls.Add(Me.tabGetInfo)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(559, 507)
        Me.TabControl1.TabIndex = 16
        '
        'tabfxLogin
        '
        Me.tabfxLogin.Controls.Add(Me.cmd1)
        Me.tabfxLogin.Controls.Add(Me.Label7)
        Me.tabfxLogin.Controls.Add(Me.Label6)
        Me.tabfxLogin.Controls.Add(Me.Label5)
        Me.tabfxLogin.Controls.Add(Me.Label4)
        Me.tabfxLogin.Controls.Add(Me.Label3)
        Me.tabfxLogin.Controls.Add(Me.Label2)
        Me.tabfxLogin.Controls.Add(Me.p106)
        Me.tabfxLogin.Controls.Add(Me.p105)
        Me.tabfxLogin.Controls.Add(Me.p104)
        Me.tabfxLogin.Controls.Add(Me.p103)
        Me.tabfxLogin.Controls.Add(Me.p102)
        Me.tabfxLogin.Controls.Add(Me.optfxLogin)
        Me.tabfxLogin.Controls.Add(Me.p101)
        Me.tabfxLogin.Location = New System.Drawing.Point(4, 22)
        Me.tabfxLogin.Name = "tabfxLogin"
        Me.tabfxLogin.Padding = New System.Windows.Forms.Padding(3)
        Me.tabfxLogin.Size = New System.Drawing.Size(551, 481)
        Me.tabfxLogin.TabIndex = 0
        Me.tabfxLogin.Text = "fxLogin"
        Me.tabfxLogin.UseVisualStyleBackColor = True
        '
        'cmd1
        '
        Me.cmd1.Location = New System.Drawing.Point(386, 145)
        Me.cmd1.Name = "cmd1"
        Me.cmd1.Size = New System.Drawing.Size(75, 32)
        Me.cmd1.TabIndex = 21
        Me.cmd1.Text = "Test"
        Me.cmd1.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(16, 162)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 13)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Usuario:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(16, 136)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(51, 13)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Sucursal:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(16, 107)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Empresa:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(16, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Sistema:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 54)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 13)
        Me.Label3.TabIndex = 16
        Me.Label3.Text = "NoSerieCLU:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(31, 13)
        Me.Label2.TabIndex = 15
        Me.Label2.Text = "RFC:"
        '
        'p106
        '
        Me.p106.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p106.Location = New System.Drawing.Point(116, 159)
        Me.p106.Name = "p106"
        Me.p106.Size = New System.Drawing.Size(264, 20)
        Me.p106.TabIndex = 14
        '
        'p105
        '
        Me.p105.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p105.Location = New System.Drawing.Point(116, 133)
        Me.p105.Name = "p105"
        Me.p105.Size = New System.Drawing.Size(264, 20)
        Me.p105.TabIndex = 13
        '
        'p104
        '
        Me.p104.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p104.Location = New System.Drawing.Point(116, 107)
        Me.p104.Name = "p104"
        Me.p104.Size = New System.Drawing.Size(264, 20)
        Me.p104.TabIndex = 12
        '
        'p103
        '
        Me.p103.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p103.Location = New System.Drawing.Point(116, 81)
        Me.p103.Name = "p103"
        Me.p103.Size = New System.Drawing.Size(264, 20)
        Me.p103.TabIndex = 11
        '
        'p102
        '
        Me.p102.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p102.Location = New System.Drawing.Point(116, 55)
        Me.p102.Name = "p102"
        Me.p102.Size = New System.Drawing.Size(264, 20)
        Me.p102.TabIndex = 10
        '
        'tabSign_Cancel
        '
        Me.tabSign_Cancel.Controls.Add(Me.Label22)
        Me.tabSign_Cancel.Controls.Add(Me.Label23)
        Me.tabSign_Cancel.Controls.Add(Me.Label24)
        Me.tabSign_Cancel.Controls.Add(Me.Label25)
        Me.tabSign_Cancel.Controls.Add(Me.p222)
        Me.tabSign_Cancel.Controls.Add(Me.p221)
        Me.tabSign_Cancel.Controls.Add(Me.p220)
        Me.tabSign_Cancel.Controls.Add(Me.p219)
        Me.tabSign_Cancel.Controls.Add(Me.Label26)
        Me.tabSign_Cancel.Controls.Add(Me.Label27)
        Me.tabSign_Cancel.Controls.Add(Me.Label28)
        Me.tabSign_Cancel.Controls.Add(Me.Label29)
        Me.tabSign_Cancel.Controls.Add(Me.Label30)
        Me.tabSign_Cancel.Controls.Add(Me.Label31)
        Me.tabSign_Cancel.Controls.Add(Me.p218)
        Me.tabSign_Cancel.Controls.Add(Me.p217)
        Me.tabSign_Cancel.Controls.Add(Me.p216)
        Me.tabSign_Cancel.Controls.Add(Me.p215)
        Me.tabSign_Cancel.Controls.Add(Me.p214)
        Me.tabSign_Cancel.Controls.Add(Me.p213)
        Me.tabSign_Cancel.Controls.Add(Me.Label14)
        Me.tabSign_Cancel.Controls.Add(Me.Label15)
        Me.tabSign_Cancel.Controls.Add(Me.Label16)
        Me.tabSign_Cancel.Controls.Add(Me.Label17)
        Me.tabSign_Cancel.Controls.Add(Me.Label18)
        Me.tabSign_Cancel.Controls.Add(Me.Label19)
        Me.tabSign_Cancel.Controls.Add(Me.p212)
        Me.tabSign_Cancel.Controls.Add(Me.p211)
        Me.tabSign_Cancel.Controls.Add(Me.p210)
        Me.tabSign_Cancel.Controls.Add(Me.p209)
        Me.tabSign_Cancel.Controls.Add(Me.p208)
        Me.tabSign_Cancel.Controls.Add(Me.p207)
        Me.tabSign_Cancel.Controls.Add(Me.cmd2)
        Me.tabSign_Cancel.Controls.Add(Me.Label8)
        Me.tabSign_Cancel.Controls.Add(Me.Label9)
        Me.tabSign_Cancel.Controls.Add(Me.Label10)
        Me.tabSign_Cancel.Controls.Add(Me.Label11)
        Me.tabSign_Cancel.Controls.Add(Me.Label12)
        Me.tabSign_Cancel.Controls.Add(Me.Label13)
        Me.tabSign_Cancel.Controls.Add(Me.p206)
        Me.tabSign_Cancel.Controls.Add(Me.p205)
        Me.tabSign_Cancel.Controls.Add(Me.p204)
        Me.tabSign_Cancel.Controls.Add(Me.p203)
        Me.tabSign_Cancel.Controls.Add(Me.p202)
        Me.tabSign_Cancel.Controls.Add(Me.p201)
        Me.tabSign_Cancel.Controls.Add(Me.RadioButton1)
        Me.tabSign_Cancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tabSign_Cancel.Location = New System.Drawing.Point(4, 22)
        Me.tabSign_Cancel.Name = "tabSign_Cancel"
        Me.tabSign_Cancel.Padding = New System.Windows.Forms.Padding(3)
        Me.tabSign_Cancel.Size = New System.Drawing.Size(551, 481)
        Me.tabSign_Cancel.TabIndex = 1
        Me.tabSign_Cancel.Text = "Sign_Cancel"
        Me.tabSign_Cancel.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(16, 377)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(32, 13)
        Me.Label22.TabIndex = 68
        Me.Label22.Text = "XML:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(286, 271)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(46, 13)
        Me.Label23.TabIndex = 67
        Me.Label23.Text = "Usuario:"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(286, 244)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(51, 13)
        Me.Label24.TabIndex = 66
        Me.Label24.Text = "Sucursal:"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(286, 219)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(51, 13)
        Me.Label25.TabIndex = 65
        Me.Label25.Text = "Empresa:"
        '
        'p222
        '
        Me.p222.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p222.Location = New System.Drawing.Point(116, 377)
        Me.p222.Multiline = True
        Me.p222.Name = "p222"
        Me.p222.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.p222.Size = New System.Drawing.Size(339, 89)
        Me.p222.TabIndex = 62
        '
        'p221
        '
        Me.p221.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p221.Location = New System.Drawing.Point(386, 271)
        Me.p221.Name = "p221"
        Me.p221.Size = New System.Drawing.Size(140, 20)
        Me.p221.TabIndex = 61
        '
        'p220
        '
        Me.p220.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p220.Location = New System.Drawing.Point(386, 245)
        Me.p220.Name = "p220"
        Me.p220.Size = New System.Drawing.Size(140, 20)
        Me.p220.TabIndex = 60
        '
        'p219
        '
        Me.p219.BackColor = System.Drawing.SystemColors.Window
        Me.p219.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p219.Location = New System.Drawing.Point(386, 219)
        Me.p219.Name = "p219"
        Me.p219.Size = New System.Drawing.Size(140, 20)
        Me.p219.TabIndex = 59
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(286, 196)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(47, 13)
        Me.Label26.TabIndex = 58
        Me.Label26.Text = "Sistema:"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(286, 170)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(27, 13)
        Me.Label27.TabIndex = 57
        Me.Label27.Text = "IET:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(286, 141)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(24, 13)
        Me.Label28.TabIndex = 56
        Me.Label28.Text = "TC:"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(286, 115)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(20, 13)
        Me.Label29.TabIndex = 55
        Me.Label29.Text = "IP:"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(286, 88)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(21, 13)
        Me.Label30.TabIndex = 54
        Me.Label30.Text = "IO:"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(286, 63)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(84, 13)
        Me.Label31.TabIndex = 53
        Me.Label31.Text = "FechaTimbrado:"
        '
        'p218
        '
        Me.p218.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p218.Location = New System.Drawing.Point(386, 193)
        Me.p218.Name = "p218"
        Me.p218.Size = New System.Drawing.Size(140, 20)
        Me.p218.TabIndex = 52
        '
        'p217
        '
        Me.p217.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p217.Location = New System.Drawing.Point(386, 167)
        Me.p217.Name = "p217"
        Me.p217.Size = New System.Drawing.Size(140, 20)
        Me.p217.TabIndex = 51
        '
        'p216
        '
        Me.p216.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p216.Location = New System.Drawing.Point(386, 141)
        Me.p216.Name = "p216"
        Me.p216.Size = New System.Drawing.Size(140, 20)
        Me.p216.TabIndex = 50
        '
        'p215
        '
        Me.p215.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p215.Location = New System.Drawing.Point(386, 115)
        Me.p215.Name = "p215"
        Me.p215.Size = New System.Drawing.Size(140, 20)
        Me.p215.TabIndex = 49
        '
        'p214
        '
        Me.p214.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p214.Location = New System.Drawing.Point(386, 89)
        Me.p214.Name = "p214"
        Me.p214.Size = New System.Drawing.Size(140, 20)
        Me.p214.TabIndex = 48
        '
        'p213
        '
        Me.p213.BackColor = System.Drawing.SystemColors.Window
        Me.p213.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p213.Location = New System.Drawing.Point(386, 63)
        Me.p213.Name = "p213"
        Me.p213.Size = New System.Drawing.Size(140, 20)
        Me.p213.TabIndex = 47
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(16, 352)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(33, 13)
        Me.Label14.TabIndex = 46
        Me.Label14.Text = "Neto:"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(16, 326)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(45, 13)
        Me.Label15.TabIndex = 45
        Me.Label15.Text = "RetISR:"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(16, 297)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(44, 13)
        Me.Label16.TabIndex = 44
        Me.Label16.Text = "RetIVA:"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(16, 271)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(27, 13)
        Me.Label17.TabIndex = 43
        Me.Label17.Text = "IVA:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(16, 244)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(45, 13)
        Me.Label18.TabIndex = 42
        Me.Label18.Text = "Importe:"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(16, 219)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(37, 13)
        Me.Label19.TabIndex = 41
        Me.Label19.Text = "UUID:"
        '
        'p212
        '
        Me.p212.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p212.Location = New System.Drawing.Point(116, 349)
        Me.p212.Name = "p212"
        Me.p212.Size = New System.Drawing.Size(140, 20)
        Me.p212.TabIndex = 40
        '
        'p211
        '
        Me.p211.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p211.Location = New System.Drawing.Point(116, 323)
        Me.p211.Name = "p211"
        Me.p211.Size = New System.Drawing.Size(140, 20)
        Me.p211.TabIndex = 39
        '
        'p210
        '
        Me.p210.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p210.Location = New System.Drawing.Point(116, 297)
        Me.p210.Name = "p210"
        Me.p210.Size = New System.Drawing.Size(140, 20)
        Me.p210.TabIndex = 38
        '
        'p209
        '
        Me.p209.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p209.Location = New System.Drawing.Point(116, 271)
        Me.p209.Name = "p209"
        Me.p209.Size = New System.Drawing.Size(140, 20)
        Me.p209.TabIndex = 37
        '
        'p208
        '
        Me.p208.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p208.Location = New System.Drawing.Point(116, 245)
        Me.p208.Name = "p208"
        Me.p208.Size = New System.Drawing.Size(140, 20)
        Me.p208.TabIndex = 36
        '
        'p207
        '
        Me.p207.BackColor = System.Drawing.SystemColors.Window
        Me.p207.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p207.Location = New System.Drawing.Point(116, 219)
        Me.p207.Name = "p207"
        Me.p207.Size = New System.Drawing.Size(140, 20)
        Me.p207.TabIndex = 35
        '
        'cmd2
        '
        Me.cmd2.Location = New System.Drawing.Point(461, 434)
        Me.cmd2.Name = "cmd2"
        Me.cmd2.Size = New System.Drawing.Size(75, 32)
        Me.cmd2.TabIndex = 34
        Me.cmd2.Text = "Test"
        Me.cmd2.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(16, 196)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(32, 13)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "Folio:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(16, 170)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(34, 13)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "Serie:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(16, 141)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(64, 13)
        Me.Label10.TabIndex = 30
        Me.Label10.Text = "FechaCFDI:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(16, 115)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 13)
        Me.Label11.TabIndex = 29
        Me.Label11.Text = "NoCertificado:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(16, 88)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(54, 13)
        Me.Label12.TabIndex = 28
        Me.Label12.Text = "Receptor:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(16, 63)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(31, 13)
        Me.Label13.TabIndex = 27
        Me.Label13.Text = "RFC:"
        '
        'p206
        '
        Me.p206.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p206.Location = New System.Drawing.Point(116, 193)
        Me.p206.Name = "p206"
        Me.p206.Size = New System.Drawing.Size(140, 20)
        Me.p206.TabIndex = 26
        '
        'p205
        '
        Me.p205.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p205.Location = New System.Drawing.Point(116, 167)
        Me.p205.Name = "p205"
        Me.p205.Size = New System.Drawing.Size(140, 20)
        Me.p205.TabIndex = 25
        '
        'p204
        '
        Me.p204.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p204.Location = New System.Drawing.Point(116, 141)
        Me.p204.Name = "p204"
        Me.p204.Size = New System.Drawing.Size(140, 20)
        Me.p204.TabIndex = 24
        '
        'p203
        '
        Me.p203.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p203.Location = New System.Drawing.Point(116, 115)
        Me.p203.Name = "p203"
        Me.p203.Size = New System.Drawing.Size(140, 20)
        Me.p203.TabIndex = 23
        '
        'p202
        '
        Me.p202.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p202.Location = New System.Drawing.Point(116, 89)
        Me.p202.Name = "p202"
        Me.p202.Size = New System.Drawing.Size(140, 20)
        Me.p202.TabIndex = 22
        '
        'p201
        '
        Me.p201.BackColor = System.Drawing.SystemColors.Window
        Me.p201.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p201.Location = New System.Drawing.Point(116, 63)
        Me.p201.Name = "p201"
        Me.p201.Size = New System.Drawing.Size(140, 20)
        Me.p201.TabIndex = 21
        '
        'RadioButton1
        '
        Me.RadioButton1.Location = New System.Drawing.Point(19, 5)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(526, 43)
        Me.RadioButton1.TabIndex = 33
        Me.RadioButton1.Text = "Sign_Cancel ($RFC,$Receptor,$NoCertificado,$FechaCFDI,$Serie, $Folio,$UUID,$Impor" & _
            "te,$IVA,$RetIVA,$RetISR,$Neto,$FechaTimbrado,$IO,$IP,$TC,$IET, $Sistema, $Empres" & _
            "a, $Sucursal, $Usuario, $XML)"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'tabUpdateCliente
        '
        Me.tabUpdateCliente.Controls.Add(Me.Label36)
        Me.tabUpdateCliente.Controls.Add(Me.p307)
        Me.tabUpdateCliente.Controls.Add(Me.cmd3)
        Me.tabUpdateCliente.Controls.Add(Me.Label20)
        Me.tabUpdateCliente.Controls.Add(Me.Label21)
        Me.tabUpdateCliente.Controls.Add(Me.Label32)
        Me.tabUpdateCliente.Controls.Add(Me.Label33)
        Me.tabUpdateCliente.Controls.Add(Me.Label34)
        Me.tabUpdateCliente.Controls.Add(Me.Label35)
        Me.tabUpdateCliente.Controls.Add(Me.p306)
        Me.tabUpdateCliente.Controls.Add(Me.p305)
        Me.tabUpdateCliente.Controls.Add(Me.p304)
        Me.tabUpdateCliente.Controls.Add(Me.p303)
        Me.tabUpdateCliente.Controls.Add(Me.p302)
        Me.tabUpdateCliente.Controls.Add(Me.p301)
        Me.tabUpdateCliente.Controls.Add(Me.optUpdateCliente)
        Me.tabUpdateCliente.Location = New System.Drawing.Point(4, 22)
        Me.tabUpdateCliente.Name = "tabUpdateCliente"
        Me.tabUpdateCliente.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUpdateCliente.Size = New System.Drawing.Size(551, 481)
        Me.tabUpdateCliente.TabIndex = 2
        Me.tabUpdateCliente.Text = "UpdateCliente"
        Me.tabUpdateCliente.UseVisualStyleBackColor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(17, 210)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(81, 13)
        Me.Label36.TabIndex = 36
        Me.Label36.Text = "Observaciones:"
        '
        'p307
        '
        Me.p307.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p307.Location = New System.Drawing.Point(117, 207)
        Me.p307.Name = "p307"
        Me.p307.Size = New System.Drawing.Size(264, 20)
        Me.p307.TabIndex = 35
        '
        'cmd3
        '
        Me.cmd3.Location = New System.Drawing.Point(388, 195)
        Me.cmd3.Name = "cmd3"
        Me.cmd3.Size = New System.Drawing.Size(75, 32)
        Me.cmd3.TabIndex = 34
        Me.cmd3.Text = "Test"
        Me.cmd3.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(18, 184)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(70, 13)
        Me.Label20.TabIndex = 33
        Me.Label20.Text = "MustContact:"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(18, 158)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(35, 13)
        Me.Label21.TabIndex = 32
        Me.Label21.Text = "ISOK:"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(18, 129)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(31, 13)
        Me.Label32.TabIndex = 31
        Me.Label32.Text = "RFC:"
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(18, 103)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(47, 13)
        Me.Label33.TabIndex = 30
        Me.Label33.Text = "Nombre:"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(18, 76)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(53, 13)
        Me.Label34.TabIndex = 29
        Me.Label34.Text = "IDCliente:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(18, 51)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(33, 13)
        Me.Label35.TabIndex = 28
        Me.Label35.Text = "NED:"
        '
        'p306
        '
        Me.p306.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p306.Location = New System.Drawing.Point(118, 181)
        Me.p306.Name = "p306"
        Me.p306.Size = New System.Drawing.Size(264, 20)
        Me.p306.TabIndex = 27
        '
        'p305
        '
        Me.p305.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p305.Location = New System.Drawing.Point(118, 155)
        Me.p305.Name = "p305"
        Me.p305.Size = New System.Drawing.Size(264, 20)
        Me.p305.TabIndex = 26
        '
        'p304
        '
        Me.p304.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p304.Location = New System.Drawing.Point(118, 129)
        Me.p304.Name = "p304"
        Me.p304.Size = New System.Drawing.Size(264, 20)
        Me.p304.TabIndex = 25
        '
        'p303
        '
        Me.p303.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p303.Location = New System.Drawing.Point(118, 103)
        Me.p303.Name = "p303"
        Me.p303.Size = New System.Drawing.Size(264, 20)
        Me.p303.TabIndex = 24
        '
        'p302
        '
        Me.p302.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p302.Location = New System.Drawing.Point(118, 77)
        Me.p302.Name = "p302"
        Me.p302.Size = New System.Drawing.Size(264, 20)
        Me.p302.TabIndex = 23
        '
        'p301
        '
        Me.p301.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p301.Location = New System.Drawing.Point(118, 51)
        Me.p301.Name = "p301"
        Me.p301.Size = New System.Drawing.Size(264, 20)
        Me.p301.TabIndex = 22
        '
        'tabUpdateCLUS
        '
        Me.tabUpdateCLUS.Controls.Add(Me.cmd4)
        Me.tabUpdateCLUS.Controls.Add(Me.Label51)
        Me.tabUpdateCLUS.Controls.Add(Me.Label52)
        Me.tabUpdateCLUS.Controls.Add(Me.Label53)
        Me.tabUpdateCLUS.Controls.Add(Me.p415)
        Me.tabUpdateCLUS.Controls.Add(Me.p414)
        Me.tabUpdateCLUS.Controls.Add(Me.p413)
        Me.tabUpdateCLUS.Controls.Add(Me.Label37)
        Me.tabUpdateCLUS.Controls.Add(Me.Label38)
        Me.tabUpdateCLUS.Controls.Add(Me.Label39)
        Me.tabUpdateCLUS.Controls.Add(Me.Label40)
        Me.tabUpdateCLUS.Controls.Add(Me.Label41)
        Me.tabUpdateCLUS.Controls.Add(Me.Label42)
        Me.tabUpdateCLUS.Controls.Add(Me.p412)
        Me.tabUpdateCLUS.Controls.Add(Me.p411)
        Me.tabUpdateCLUS.Controls.Add(Me.p410)
        Me.tabUpdateCLUS.Controls.Add(Me.p409)
        Me.tabUpdateCLUS.Controls.Add(Me.p408)
        Me.tabUpdateCLUS.Controls.Add(Me.p407)
        Me.tabUpdateCLUS.Controls.Add(Me.Label43)
        Me.tabUpdateCLUS.Controls.Add(Me.Label44)
        Me.tabUpdateCLUS.Controls.Add(Me.Label45)
        Me.tabUpdateCLUS.Controls.Add(Me.Label46)
        Me.tabUpdateCLUS.Controls.Add(Me.Label47)
        Me.tabUpdateCLUS.Controls.Add(Me.Label48)
        Me.tabUpdateCLUS.Controls.Add(Me.p406)
        Me.tabUpdateCLUS.Controls.Add(Me.p405)
        Me.tabUpdateCLUS.Controls.Add(Me.p404)
        Me.tabUpdateCLUS.Controls.Add(Me.p403)
        Me.tabUpdateCLUS.Controls.Add(Me.p402)
        Me.tabUpdateCLUS.Controls.Add(Me.p401)
        Me.tabUpdateCLUS.Controls.Add(Me.optUpdateCLUS)
        Me.tabUpdateCLUS.Location = New System.Drawing.Point(4, 22)
        Me.tabUpdateCLUS.Name = "tabUpdateCLUS"
        Me.tabUpdateCLUS.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUpdateCLUS.Size = New System.Drawing.Size(551, 481)
        Me.tabUpdateCLUS.TabIndex = 3
        Me.tabUpdateCLUS.Text = "UpdateCLUS"
        Me.tabUpdateCLUS.UseVisualStyleBackColor = True
        '
        'cmd4
        '
        Me.cmd4.Location = New System.Drawing.Point(451, 156)
        Me.cmd4.Name = "cmd4"
        Me.cmd4.Size = New System.Drawing.Size(75, 32)
        Me.cmd4.TabIndex = 79
        Me.cmd4.Text = "Test"
        Me.cmd4.UseVisualStyleBackColor = True
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(286, 127)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(81, 13)
        Me.Label51.TabIndex = 78
        Me.Label51.Text = "Observaciones:"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(286, 100)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(45, 13)
        Me.Label52.TabIndex = 77
        Me.Label52.Text = "Estatus:"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(286, 75)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(77, 13)
        Me.Label53.TabIndex = 76
        Me.Label53.Text = "KindOfAccess:"
        '
        'p415
        '
        Me.p415.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p415.Location = New System.Drawing.Point(386, 127)
        Me.p415.Name = "p415"
        Me.p415.Size = New System.Drawing.Size(140, 20)
        Me.p415.TabIndex = 73
        '
        'p414
        '
        Me.p414.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p414.Location = New System.Drawing.Point(386, 101)
        Me.p414.Name = "p414"
        Me.p414.Size = New System.Drawing.Size(140, 20)
        Me.p414.TabIndex = 72
        '
        'p413
        '
        Me.p413.BackColor = System.Drawing.SystemColors.Window
        Me.p413.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p413.Location = New System.Drawing.Point(386, 75)
        Me.p413.Name = "p413"
        Me.p413.Size = New System.Drawing.Size(140, 20)
        Me.p413.TabIndex = 71
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(14, 364)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(62, 13)
        Me.Label37.TabIndex = 70
        Me.Label37.Text = "CanCancel:"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(14, 338)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(47, 13)
        Me.Label38.TabIndex = 69
        Me.Label38.Text = "CanSign"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(14, 309)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(64, 13)
        Me.Label39.TabIndex = 68
        Me.Label39.Text = "CanAccess:"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(14, 283)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(67, 13)
        Me.Label40.TabIndex = 67
        Me.Label40.Text = "ValidoHasta:"
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(14, 256)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(70, 13)
        Me.Label41.TabIndex = 66
        Me.Label41.Text = "ValidoDesde:"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(14, 231)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(50, 13)
        Me.Label42.TabIndex = 65
        Me.Label42.Text = "Modulos:"
        '
        'p412
        '
        Me.p412.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p412.Location = New System.Drawing.Point(114, 361)
        Me.p412.Name = "p412"
        Me.p412.Size = New System.Drawing.Size(140, 20)
        Me.p412.TabIndex = 64
        '
        'p411
        '
        Me.p411.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p411.Location = New System.Drawing.Point(114, 335)
        Me.p411.Name = "p411"
        Me.p411.Size = New System.Drawing.Size(140, 20)
        Me.p411.TabIndex = 63
        '
        'p410
        '
        Me.p410.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p410.Location = New System.Drawing.Point(114, 309)
        Me.p410.Name = "p410"
        Me.p410.Size = New System.Drawing.Size(140, 20)
        Me.p410.TabIndex = 62
        '
        'p409
        '
        Me.p409.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p409.Location = New System.Drawing.Point(114, 283)
        Me.p409.Name = "p409"
        Me.p409.Size = New System.Drawing.Size(140, 20)
        Me.p409.TabIndex = 61
        '
        'p408
        '
        Me.p408.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p408.Location = New System.Drawing.Point(114, 257)
        Me.p408.Name = "p408"
        Me.p408.Size = New System.Drawing.Size(140, 20)
        Me.p408.TabIndex = 60
        '
        'p407
        '
        Me.p407.BackColor = System.Drawing.SystemColors.Window
        Me.p407.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p407.Location = New System.Drawing.Point(114, 231)
        Me.p407.Name = "p407"
        Me.p407.Size = New System.Drawing.Size(140, 20)
        Me.p407.TabIndex = 59
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(14, 208)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(47, 13)
        Me.Label43.TabIndex = 58
        Me.Label43.Text = "Sistema:"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(14, 182)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(31, 13)
        Me.Label44.TabIndex = 57
        Me.Label44.Text = "RFC:"
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(14, 153)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(53, 13)
        Me.Label45.TabIndex = 56
        Me.Label45.Text = "IDCliente:"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(14, 127)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(48, 13)
        Me.Label46.TabIndex = 55
        Me.Label46.Text = "NoSerie:"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(14, 100)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(42, 13)
        Me.Label47.TabIndex = 54
        Me.Label47.Text = "IDCLU:"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(14, 75)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(33, 13)
        Me.Label48.TabIndex = 53
        Me.Label48.Text = "NED:"
        '
        'p406
        '
        Me.p406.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p406.Location = New System.Drawing.Point(114, 205)
        Me.p406.Name = "p406"
        Me.p406.Size = New System.Drawing.Size(140, 20)
        Me.p406.TabIndex = 52
        '
        'p405
        '
        Me.p405.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p405.Location = New System.Drawing.Point(114, 179)
        Me.p405.Name = "p405"
        Me.p405.Size = New System.Drawing.Size(140, 20)
        Me.p405.TabIndex = 51
        '
        'p404
        '
        Me.p404.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p404.Location = New System.Drawing.Point(114, 153)
        Me.p404.Name = "p404"
        Me.p404.Size = New System.Drawing.Size(140, 20)
        Me.p404.TabIndex = 50
        '
        'p403
        '
        Me.p403.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p403.Location = New System.Drawing.Point(114, 127)
        Me.p403.Name = "p403"
        Me.p403.Size = New System.Drawing.Size(140, 20)
        Me.p403.TabIndex = 49
        '
        'p402
        '
        Me.p402.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p402.Location = New System.Drawing.Point(114, 101)
        Me.p402.Name = "p402"
        Me.p402.Size = New System.Drawing.Size(140, 20)
        Me.p402.TabIndex = 48
        '
        'p401
        '
        Me.p401.BackColor = System.Drawing.SystemColors.Window
        Me.p401.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p401.Location = New System.Drawing.Point(114, 75)
        Me.p401.Name = "p401"
        Me.p401.Size = New System.Drawing.Size(140, 20)
        Me.p401.TabIndex = 47
        '
        'tabUpdateMsgs
        '
        Me.tabUpdateMsgs.Controls.Add(Me.cmd5)
        Me.tabUpdateMsgs.Controls.Add(Me.Label49)
        Me.tabUpdateMsgs.Controls.Add(Me.Label50)
        Me.tabUpdateMsgs.Controls.Add(Me.Label54)
        Me.tabUpdateMsgs.Controls.Add(Me.Label55)
        Me.tabUpdateMsgs.Controls.Add(Me.Label56)
        Me.tabUpdateMsgs.Controls.Add(Me.Label57)
        Me.tabUpdateMsgs.Controls.Add(Me.p506)
        Me.tabUpdateMsgs.Controls.Add(Me.p505)
        Me.tabUpdateMsgs.Controls.Add(Me.p504)
        Me.tabUpdateMsgs.Controls.Add(Me.p503)
        Me.tabUpdateMsgs.Controls.Add(Me.p502)
        Me.tabUpdateMsgs.Controls.Add(Me.p501)
        Me.tabUpdateMsgs.Controls.Add(Me.optUpdateMsgs)
        Me.tabUpdateMsgs.Location = New System.Drawing.Point(4, 22)
        Me.tabUpdateMsgs.Name = "tabUpdateMsgs"
        Me.tabUpdateMsgs.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUpdateMsgs.Size = New System.Drawing.Size(551, 481)
        Me.tabUpdateMsgs.TabIndex = 4
        Me.tabUpdateMsgs.Text = "UpdateMsgs"
        Me.tabUpdateMsgs.UseVisualStyleBackColor = True
        '
        'cmd5
        '
        Me.cmd5.Location = New System.Drawing.Point(391, 166)
        Me.cmd5.Name = "cmd5"
        Me.cmd5.Size = New System.Drawing.Size(75, 32)
        Me.cmd5.TabIndex = 34
        Me.cmd5.Text = "Test"
        Me.cmd5.UseVisualStyleBackColor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(21, 183)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(67, 13)
        Me.Label49.TabIndex = 33
        Me.Label49.Text = "ValidoHasta:"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(21, 157)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(70, 13)
        Me.Label50.TabIndex = 32
        Me.Label50.Text = "ValidoDesde:"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(21, 128)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(50, 13)
        Me.Label54.TabIndex = 31
        Me.Label54.Text = "Mensaje:"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(21, 102)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(53, 13)
        Me.Label55.TabIndex = 30
        Me.Label55.Text = "IDCliente:"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(21, 75)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(46, 13)
        Me.Label56.TabIndex = 29
        Me.Label56.Text = "IDMsgs:"
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(21, 50)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(33, 13)
        Me.Label57.TabIndex = 28
        Me.Label57.Text = "NED:"
        '
        'p506
        '
        Me.p506.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p506.Location = New System.Drawing.Point(121, 180)
        Me.p506.Name = "p506"
        Me.p506.Size = New System.Drawing.Size(264, 20)
        Me.p506.TabIndex = 27
        '
        'p505
        '
        Me.p505.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p505.Location = New System.Drawing.Point(121, 154)
        Me.p505.Name = "p505"
        Me.p505.Size = New System.Drawing.Size(264, 20)
        Me.p505.TabIndex = 26
        '
        'p504
        '
        Me.p504.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p504.Location = New System.Drawing.Point(121, 128)
        Me.p504.Name = "p504"
        Me.p504.Size = New System.Drawing.Size(264, 20)
        Me.p504.TabIndex = 25
        '
        'p503
        '
        Me.p503.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p503.Location = New System.Drawing.Point(121, 102)
        Me.p503.Name = "p503"
        Me.p503.Size = New System.Drawing.Size(264, 20)
        Me.p503.TabIndex = 24
        '
        'p502
        '
        Me.p502.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p502.Location = New System.Drawing.Point(121, 76)
        Me.p502.Name = "p502"
        Me.p502.Size = New System.Drawing.Size(264, 20)
        Me.p502.TabIndex = 23
        '
        'p501
        '
        Me.p501.BackColor = System.Drawing.SystemColors.Window
        Me.p501.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p501.Location = New System.Drawing.Point(121, 50)
        Me.p501.Name = "p501"
        Me.p501.Size = New System.Drawing.Size(264, 20)
        Me.p501.TabIndex = 22
        '
        'tabUpdateCatTimbres
        '
        Me.tabUpdateCatTimbres.Controls.Add(Me.Label65)
        Me.tabUpdateCatTimbres.Controls.Add(Me.p608)
        Me.tabUpdateCatTimbres.Controls.Add(Me.Label58)
        Me.tabUpdateCatTimbres.Controls.Add(Me.p607)
        Me.tabUpdateCatTimbres.Controls.Add(Me.cmd6)
        Me.tabUpdateCatTimbres.Controls.Add(Me.Label59)
        Me.tabUpdateCatTimbres.Controls.Add(Me.Label60)
        Me.tabUpdateCatTimbres.Controls.Add(Me.Label61)
        Me.tabUpdateCatTimbres.Controls.Add(Me.Label62)
        Me.tabUpdateCatTimbres.Controls.Add(Me.Label63)
        Me.tabUpdateCatTimbres.Controls.Add(Me.Label64)
        Me.tabUpdateCatTimbres.Controls.Add(Me.p606)
        Me.tabUpdateCatTimbres.Controls.Add(Me.p605)
        Me.tabUpdateCatTimbres.Controls.Add(Me.p604)
        Me.tabUpdateCatTimbres.Controls.Add(Me.p603)
        Me.tabUpdateCatTimbres.Controls.Add(Me.p602)
        Me.tabUpdateCatTimbres.Controls.Add(Me.p601)
        Me.tabUpdateCatTimbres.Controls.Add(Me.optUpdateCatTimbres)
        Me.tabUpdateCatTimbres.Location = New System.Drawing.Point(4, 22)
        Me.tabUpdateCatTimbres.Name = "tabUpdateCatTimbres"
        Me.tabUpdateCatTimbres.Padding = New System.Windows.Forms.Padding(3)
        Me.tabUpdateCatTimbres.Size = New System.Drawing.Size(551, 481)
        Me.tabUpdateCatTimbres.TabIndex = 5
        Me.tabUpdateCatTimbres.Text = "UpdateCatTimbres"
        Me.tabUpdateCatTimbres.UseVisualStyleBackColor = True
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(28, 247)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(81, 13)
        Me.Label65.TabIndex = 53
        Me.Label65.Text = "Observaciones:"
        '
        'p608
        '
        Me.p608.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p608.Location = New System.Drawing.Point(128, 244)
        Me.p608.Name = "p608"
        Me.p608.Size = New System.Drawing.Size(264, 20)
        Me.p608.TabIndex = 52
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(27, 221)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(45, 13)
        Me.Label58.TabIndex = 51
        Me.Label58.Text = "Estatus:"
        '
        'p607
        '
        Me.p607.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p607.Location = New System.Drawing.Point(127, 218)
        Me.p607.Name = "p607"
        Me.p607.Size = New System.Drawing.Size(264, 20)
        Me.p607.TabIndex = 50
        '
        'cmd6
        '
        Me.cmd6.Location = New System.Drawing.Point(411, 232)
        Me.cmd6.Name = "cmd6"
        Me.cmd6.Size = New System.Drawing.Size(75, 32)
        Me.cmd6.TabIndex = 49
        Me.cmd6.Text = "Test"
        Me.cmd6.UseVisualStyleBackColor = True
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(28, 195)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(71, 13)
        Me.Label59.TabIndex = 48
        Me.Label59.Text = "TotalTimbres:"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(28, 169)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(71, 13)
        Me.Label60.TabIndex = 47
        Me.Label60.Text = "ContratadoEl:"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(28, 140)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(31, 13)
        Me.Label61.TabIndex = 46
        Me.Label61.Text = "RFC:"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(28, 114)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(53, 13)
        Me.Label62.TabIndex = 45
        Me.Label62.Text = "IDCliente:"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(28, 87)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(69, 13)
        Me.Label63.TabIndex = 44
        Me.Label63.Text = "IDCatTimbre:"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(28, 62)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(33, 13)
        Me.Label64.TabIndex = 43
        Me.Label64.Text = "NED:"
        '
        'p606
        '
        Me.p606.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p606.Location = New System.Drawing.Point(128, 192)
        Me.p606.Name = "p606"
        Me.p606.Size = New System.Drawing.Size(264, 20)
        Me.p606.TabIndex = 42
        '
        'p605
        '
        Me.p605.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p605.Location = New System.Drawing.Point(128, 166)
        Me.p605.Name = "p605"
        Me.p605.Size = New System.Drawing.Size(264, 20)
        Me.p605.TabIndex = 41
        '
        'p604
        '
        Me.p604.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p604.Location = New System.Drawing.Point(128, 140)
        Me.p604.Name = "p604"
        Me.p604.Size = New System.Drawing.Size(264, 20)
        Me.p604.TabIndex = 40
        '
        'p603
        '
        Me.p603.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p603.Location = New System.Drawing.Point(128, 114)
        Me.p603.Name = "p603"
        Me.p603.Size = New System.Drawing.Size(264, 20)
        Me.p603.TabIndex = 39
        '
        'p602
        '
        Me.p602.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p602.Location = New System.Drawing.Point(128, 88)
        Me.p602.Name = "p602"
        Me.p602.Size = New System.Drawing.Size(264, 20)
        Me.p602.TabIndex = 38
        '
        'p601
        '
        Me.p601.BackColor = System.Drawing.SystemColors.Window
        Me.p601.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p601.Location = New System.Drawing.Point(128, 62)
        Me.p601.Name = "p601"
        Me.p601.Size = New System.Drawing.Size(264, 20)
        Me.p601.TabIndex = 37
        '
        'tabGetInfo
        '
        Me.tabGetInfo.Controls.Add(Me.p701)
        Me.tabGetInfo.Controls.Add(Me.GridGetInfo)
        Me.tabGetInfo.Controls.Add(Me.Label66)
        Me.tabGetInfo.Controls.Add(Me.p702)
        Me.tabGetInfo.Controls.Add(Me.Label67)
        Me.tabGetInfo.Controls.Add(Me.cmd7)
        Me.tabGetInfo.Controls.Add(Me.optGetInfo)
        Me.tabGetInfo.Location = New System.Drawing.Point(4, 22)
        Me.tabGetInfo.Name = "tabGetInfo"
        Me.tabGetInfo.Padding = New System.Windows.Forms.Padding(3)
        Me.tabGetInfo.Size = New System.Drawing.Size(551, 481)
        Me.tabGetInfo.TabIndex = 6
        Me.tabGetInfo.Text = "GetInfo"
        Me.tabGetInfo.UseVisualStyleBackColor = True
        '
        'p701
        '
        Me.p701.FormattingEnabled = True
        Me.p701.Items.AddRange(New Object() {"tblalertas", "tblcattimbres", "tblclientes", "tblclus", "tbllogin", "tblmsgs", "tbltimbres", "tbltimbresi"})
        Me.p701.Location = New System.Drawing.Point(121, 52)
        Me.p701.Name = "p701"
        Me.p701.Size = New System.Drawing.Size(264, 21)
        Me.p701.TabIndex = 60
        '
        'GridGetInfo
        '
        Me.GridGetInfo.AllowUserToAddRows = False
        Me.GridGetInfo.AllowUserToDeleteRows = False
        Me.GridGetInfo.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GridGetInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridGetInfo.Location = New System.Drawing.Point(15, 117)
        Me.GridGetInfo.Name = "GridGetInfo"
        Me.GridGetInfo.ReadOnly = True
        Me.GridGetInfo.Size = New System.Drawing.Size(517, 352)
        Me.GridGetInfo.TabIndex = 59
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(21, 82)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(37, 13)
        Me.Label66.TabIndex = 58
        Me.Label66.Text = "Filtros:"
        '
        'p702
        '
        Me.p702.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.p702.Location = New System.Drawing.Point(121, 79)
        Me.p702.Name = "p702"
        Me.p702.Size = New System.Drawing.Size(264, 20)
        Me.p702.TabIndex = 57
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(20, 56)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(37, 13)
        Me.Label67.TabIndex = 56
        Me.Label67.Text = "Tabla:"
        '
        'cmd7
        '
        Me.cmd7.Location = New System.Drawing.Point(404, 67)
        Me.cmd7.Name = "cmd7"
        Me.cmd7.Size = New System.Drawing.Size(75, 32)
        Me.cmd7.TabIndex = 54
        Me.cmd7.Text = "Test"
        Me.cmd7.UseVisualStyleBackColor = True
        '
        'frmWS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1027, 531)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtResultado)
        Me.Name = "frmWS"
        Me.Text = "frmWS"
        Me.TabControl1.ResumeLayout(False)
        Me.tabfxLogin.ResumeLayout(False)
        Me.tabfxLogin.PerformLayout()
        Me.tabSign_Cancel.ResumeLayout(False)
        Me.tabSign_Cancel.PerformLayout()
        Me.tabUpdateCliente.ResumeLayout(False)
        Me.tabUpdateCliente.PerformLayout()
        Me.tabUpdateCLUS.ResumeLayout(False)
        Me.tabUpdateCLUS.PerformLayout()
        Me.tabUpdateMsgs.ResumeLayout(False)
        Me.tabUpdateMsgs.PerformLayout()
        Me.tabUpdateCatTimbres.ResumeLayout(False)
        Me.tabUpdateCatTimbres.PerformLayout()
        Me.tabGetInfo.ResumeLayout(False)
        Me.tabGetInfo.PerformLayout()
        CType(Me.GridGetInfo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents optfxLogin As System.Windows.Forms.RadioButton
    Friend WithEvents optUpdateCLUS As System.Windows.Forms.RadioButton
    Friend WithEvents optUpdateCliente As System.Windows.Forms.RadioButton
    Friend WithEvents optUpdateCatTimbres As System.Windows.Forms.RadioButton
    Friend WithEvents optUpdateMsgs As System.Windows.Forms.RadioButton
    Friend WithEvents optGetInfo As System.Windows.Forms.RadioButton
    Friend WithEvents p101 As System.Windows.Forms.TextBox
    Friend WithEvents txtResultado As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabfxLogin As System.Windows.Forms.TabPage
    Friend WithEvents cmd1 As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents p106 As System.Windows.Forms.TextBox
    Friend WithEvents p105 As System.Windows.Forms.TextBox
    Friend WithEvents p104 As System.Windows.Forms.TextBox
    Friend WithEvents p103 As System.Windows.Forms.TextBox
    Friend WithEvents p102 As System.Windows.Forms.TextBox
    Friend WithEvents tabSign_Cancel As System.Windows.Forms.TabPage
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents p222 As System.Windows.Forms.TextBox
    Friend WithEvents p221 As System.Windows.Forms.TextBox
    Friend WithEvents p220 As System.Windows.Forms.TextBox
    Friend WithEvents p219 As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents p218 As System.Windows.Forms.TextBox
    Friend WithEvents p217 As System.Windows.Forms.TextBox
    Friend WithEvents p216 As System.Windows.Forms.TextBox
    Friend WithEvents p215 As System.Windows.Forms.TextBox
    Friend WithEvents p214 As System.Windows.Forms.TextBox
    Friend WithEvents p213 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents p212 As System.Windows.Forms.TextBox
    Friend WithEvents p211 As System.Windows.Forms.TextBox
    Friend WithEvents p210 As System.Windows.Forms.TextBox
    Friend WithEvents p209 As System.Windows.Forms.TextBox
    Friend WithEvents p208 As System.Windows.Forms.TextBox
    Friend WithEvents p207 As System.Windows.Forms.TextBox
    Friend WithEvents cmd2 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents p206 As System.Windows.Forms.TextBox
    Friend WithEvents p205 As System.Windows.Forms.TextBox
    Friend WithEvents p204 As System.Windows.Forms.TextBox
    Friend WithEvents p203 As System.Windows.Forms.TextBox
    Friend WithEvents p202 As System.Windows.Forms.TextBox
    Friend WithEvents p201 As System.Windows.Forms.TextBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents tabUpdateCliente As System.Windows.Forms.TabPage
    Friend WithEvents tabUpdateCLUS As System.Windows.Forms.TabPage
    Friend WithEvents tabUpdateMsgs As System.Windows.Forms.TabPage
    Friend WithEvents tabUpdateCatTimbres As System.Windows.Forms.TabPage
    Friend WithEvents tabGetInfo As System.Windows.Forms.TabPage
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents p307 As System.Windows.Forms.TextBox
    Friend WithEvents cmd3 As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents p306 As System.Windows.Forms.TextBox
    Friend WithEvents p305 As System.Windows.Forms.TextBox
    Friend WithEvents p304 As System.Windows.Forms.TextBox
    Friend WithEvents p303 As System.Windows.Forms.TextBox
    Friend WithEvents p302 As System.Windows.Forms.TextBox
    Friend WithEvents p301 As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents p415 As System.Windows.Forms.TextBox
    Friend WithEvents p414 As System.Windows.Forms.TextBox
    Friend WithEvents p413 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents p412 As System.Windows.Forms.TextBox
    Friend WithEvents p411 As System.Windows.Forms.TextBox
    Friend WithEvents p410 As System.Windows.Forms.TextBox
    Friend WithEvents p409 As System.Windows.Forms.TextBox
    Friend WithEvents p408 As System.Windows.Forms.TextBox
    Friend WithEvents p407 As System.Windows.Forms.TextBox
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents p406 As System.Windows.Forms.TextBox
    Friend WithEvents p405 As System.Windows.Forms.TextBox
    Friend WithEvents p404 As System.Windows.Forms.TextBox
    Friend WithEvents p403 As System.Windows.Forms.TextBox
    Friend WithEvents p402 As System.Windows.Forms.TextBox
    Friend WithEvents p401 As System.Windows.Forms.TextBox
    Friend WithEvents cmd4 As System.Windows.Forms.Button
    Friend WithEvents cmd5 As System.Windows.Forms.Button
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents p506 As System.Windows.Forms.TextBox
    Friend WithEvents p505 As System.Windows.Forms.TextBox
    Friend WithEvents p504 As System.Windows.Forms.TextBox
    Friend WithEvents p503 As System.Windows.Forms.TextBox
    Friend WithEvents p502 As System.Windows.Forms.TextBox
    Friend WithEvents p501 As System.Windows.Forms.TextBox
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents p608 As System.Windows.Forms.TextBox
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents p607 As System.Windows.Forms.TextBox
    Friend WithEvents cmd6 As System.Windows.Forms.Button
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents p606 As System.Windows.Forms.TextBox
    Friend WithEvents p605 As System.Windows.Forms.TextBox
    Friend WithEvents p604 As System.Windows.Forms.TextBox
    Friend WithEvents p603 As System.Windows.Forms.TextBox
    Friend WithEvents p602 As System.Windows.Forms.TextBox
    Friend WithEvents p601 As System.Windows.Forms.TextBox
    Friend WithEvents GridGetInfo As System.Windows.Forms.DataGridView
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents p702 As System.Windows.Forms.TextBox
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents cmd7 As System.Windows.Forms.Button
    Friend WithEvents p701 As System.Windows.Forms.ComboBox
End Class
